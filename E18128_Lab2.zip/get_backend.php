<html>
    <body>
        <h1> Your Information System </h1>
<?php
    if (isset($_GET['submit'])){
        $search=$_GET['search_button'];
        $size=$_GET['size'];
        $color=$_GET['color'];
        $extraitem=$_GET['extra_items'];
        $fname=$_GET['First_Name'];
        $lname=$_GET['Last_Name'];
        $address1=$_GET['Address1'];
        $address2=$_GET['Address2'];
        $address3=$_GET['Address3'];
        $comment=$_GET['comments'];
        echo "Thank you ". $fname . " for your purchase from our website<br><br>";
        
        echo "Your item colour is : ".$color. " & T-Shirt size :" .$size."<br><br>";

        echo "Selected items/ item are <br><br>";

        // echo.$extraitem. "<br><br>";
        foreach ($extraitem as $item){
            echo  "*" .$item. "<br>"; 
        }

        echo "<br>";

        echo "Your items will be sent to <br>";

        echo "<br><i>$fname $lname,<br>";
        echo "$address1,<br>";
        echo "$address2,<br>";
        echo "$address3</i><br>";

        echo "<br>Thank you for submitting your comments. We appreciate it. You said:<br>";
  
        echo "<br><i>$comment<br>";

    }

?>

</body>
</html>