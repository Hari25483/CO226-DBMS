<html>
    <body>
        <h1> Your Information System </h1>
<?php
    if (isset($_POST['submit'])){
        $search=$_POST['search_button'];
        $size=$_POST['size'];
        $color=$_POST['color'];
        $extraitem=$_POST['extra_items']??null;
        $fname=$_POST['First_Name'];
        $lname=$_POST['Last_Name'];
        $address1=$_POST['Address1'];
        $address2=$_POST['Address2'];
        $address3=$_POST['Address3'];
        $comment=$_POST['comments'];
        echo "Thank you ". $fname . " for your purchase from our website<br><br>";
        
        echo "Your item colour is : ".$color. " & T-Shirt size :" .$size."<br><br>";

        echo "Selected items/ item are <br><br>";

        foreach ($extraitem as $item){
            echo  "*" .$item. "<br>"; 
        }

        echo "<br>";

        echo "Your items will be sent to <br>";

        echo "<br><i>$fname $lname,<br>";
        echo "$address1,<br>";
        echo "$address2,<br>";
        echo "$address3</i><br>";

        echo "<br>Thank you for submitting your comments. We appreciate it. You said:<br>";
  
        echo "<br><i>$comment<br>";

    }

?>
</body>
</html>